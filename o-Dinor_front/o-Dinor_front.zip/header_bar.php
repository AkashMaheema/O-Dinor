<style>
    .header__bar {
        
        position: fixed;
        top:70px;
        z-index: 99;
        width: 100%;
        padding: 0.5rem;
        font-size: 0.8rem;
        text-align: center;
        background-color: #000000;
        color: #ffffff;
    }
</style>
<div class="header__bar">Free shipping on Orders Over $50</div>